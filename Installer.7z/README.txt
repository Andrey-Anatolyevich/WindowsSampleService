1) Place .BATs by compiled .exe
2) Run Install with ADMIN rights

To remove: the same for UnInstall